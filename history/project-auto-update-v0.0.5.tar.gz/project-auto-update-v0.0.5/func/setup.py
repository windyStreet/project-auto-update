#!/usr/bin/env python
#!-*- coding:utf-8 -*-
'''
Created on 2016年10月18日14:50:55

@author: windyStreet
'''

class SetUp(object):
    '''
    classdocs 项目安装
    '''
    def __init__(self, params):
        '''
        Constructor
        '''
    def setUp(self):
        print("setUp")